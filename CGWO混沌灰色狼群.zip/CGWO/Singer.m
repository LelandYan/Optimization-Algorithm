function x=Singer(n,level,a,x0)

if x0==0
    x0=0.4;
end

u=1.07;
x(1)=u*(7.86*x0-23.31*(x0^2)+28.75*(x0^3)-13.302875*(x0^4));
for i=2:n
    x(i) = u*(7.86*x(i-1)-23.31*(x(i-1)^2)+28.75*(x(i-1)^3)-13.302875*(x(i-1)^4));
end
% Add normal white noise
x=x+randn(1,n)*level*std(x);