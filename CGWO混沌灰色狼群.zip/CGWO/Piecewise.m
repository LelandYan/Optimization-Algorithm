function x=Piecewise(n,level,a,x0)
P=0.4;
x(1)=x0;
for i=1:n
    if x(i)>=0 && x(i)<P
        x(i+1)=x(i)/P;
    elseif x(i)>=P && x(i)<0.5
        x(i+1)=(x(i)-P)/(0.5-P);
    elseif x(i)>=0.5 && x(i)<1-P
        x(i+1)=(1-P-x(i))/(0.5-P);
    elseif x(i)>=1-P && x(i)<1
        x(i+1)=(1-x(i))/P;
    end    
end
x=x(2:end);
x=x+randn(1,n)*level*std(x);