function [Alpha_score,Alpha_pos,Positions]=CGWOLOG(SearchAgents_no,Max_iter,lb,ub,dim,fobj,x)
[Alpha_score,Alpha_pos,Positions]=CGWO(SearchAgents_no,Max_iter,lb,ub,dim,fobj,x,[],'logistic');
