function [y, cp]=Acc(x)
%fitness based on accuracy of classification
global A trn tst vald ts_flg
x=x>0.5;
x=logical(x);
x=cat(2,x,zeros(size(x,1),1));
x=logical(x);
% fprintf('%d',x);fprintf('\n');
% disp(x)
if sum(x)==0
    y=inf;
    return;
end
if ts_flg
    c = knnclassify(A(tst,x),A(trn,x),A(trn,end),5);
    cp = classperf(A(tst,end),c);
else
    c = knnclassify(A(vald,x),A(trn,x),A(trn,end),5);
    cp = classperf(A(vald,end),c);
end
y=1-cp.CorrectRate;      
