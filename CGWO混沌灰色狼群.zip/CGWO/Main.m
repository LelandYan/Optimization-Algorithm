function Main
%the main function that can call all the chaos maps

%The maps to be called LOG, singer, sinusoidal and tent map
%this implementation is based on the paper by:
% Emary E, Zawbaa HM, (2016) Impact of chaos functions on modern swarm optimizers. PLoS ONE 11(7): e0158738, July 
%2016. DOI: 10.1371/journal.pone.0158738.
%http://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0158738
%All work making use of such code must cite that paper.

global A trn tst vald
A=load('zoo.dat');
KFld=3;
Indices=crossvalind('Kfold', size(A,1), KFld);
for i=1:KFld
    nonTst=find(Indices~=i);
    nonTst=nonTst(randperm(length(nonTst)));
    trn=nonTst(1:floor(length(nonTst)/2));%CVO(1:sz);%index of samples in the training data
    tst=find(Indices==i);%CVO(sz+1:en);%index of samples in the test data
    
    vald=nonTst(floor(length(nonTst)/2)+1:end);%CVO(en+1:end);%index of samples in the validation data
    nC=unique(A(vald,end));
    
    if length(nC)==1, continue;end
    
    dim=size(A,2)-1;
    NAgents=5;
    Iter=100;
    
    [Alpha_score,Alpha_pos,Positions]=CGWOLOG(NAgents,Iter,0,1,dim,'Acc',[]);
    
    [Alpha_score,Alpha_pos,Positions]=CGWOSINGER(NAgents,Iter,0,1,dim,'Acc',[]);
    
    [Alpha_score,Alpha_pos,Positions]=CGWOSINUSOIDAL(NAgents,Iter,0,1,dim,'Acc',[]);
    
    [Alpha_score,Alpha_pos,Positions]=CGWOTENT(NAgents,Iter,0,1,dim,'Acc',[]);
end