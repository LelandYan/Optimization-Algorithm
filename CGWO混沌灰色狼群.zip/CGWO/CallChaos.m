function x=CallChaos(n,mapName)
global x0
if isempty(x0)
    x0=rand;
    if x0==0
        x0=0.1;
    end
end
eval(sprintf('x=%s(n,0.1,4,x0);',mapName));
%x=logistic(n,0,4,x0);
% x=sinsuidal(n,0,0,x0);
% x=Tent(n,0,0,x0);
% x=Singer(n,0,0,x0);
% x=Piecewise(n,0,0,x0);
x0=x(end);