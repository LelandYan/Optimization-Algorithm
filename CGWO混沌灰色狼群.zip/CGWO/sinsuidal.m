function x=sinsuidal(n,level,a,x0)


if x0==0
    x0=0.8;
end

% Initialize
x(1)=2.3*x0^2*sin(pi*x0);

% Simulate
for i=2:n
    x(i)=2.3*x(i-1)^2*sin(pi*x(i-1));
end

% Add normal white noise
x=x+randn(1,n)*level*std(x);% x(i+1) = 2.3*x(i)^2*sin(pi*x(i));
